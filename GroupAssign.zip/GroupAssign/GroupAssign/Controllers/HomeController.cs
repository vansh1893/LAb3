using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

public class HomeController : Controller
{
    [HttpGet]
    public IActionResult Login()
    {
        var redirectUrl = Url.Action(nameof(GoogleResponse));
        var properties = new AuthenticationProperties { RedirectUri = redirectUrl };
        return Challenge(properties, GoogleDefaults.AuthenticationScheme);
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync();
        return RedirectToAction(nameof(HomePage));
    }

    [HttpGet]
    public async Task<IActionResult> GoogleResponse()
    {
        var result = await HttpContext.AuthenticateAsync();
        if (!result.Succeeded)
        {
            return RedirectToAction(nameof(Login));
        }

        ViewBag.Name = result.Principal.FindFirst(c => c.Type == "name")?.Value;
        ViewBag.Email = result.Principal.FindFirst(c => c.Type == "email")?.Value;

        return View();
    }

    [HttpGet]
    public IActionResult HomePage()
    {
        return View();
    }
   
}
